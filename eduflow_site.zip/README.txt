
EduFlow — Static multi-page template with Firebase auth integration
-----------------------------------------------------------------

Files:
- index.html, features.html, courses.html, pricing.html, testimonials.html, blog.html, contact.html
- signup.html, login.html
- firebase.js  <-- paste your Firebase web app config into this file (see comments)
- README.txt

How to use:
1. Unzip the package and open index.html in a browser to preview.
2. Open firebase.js and paste your Firebase config into the FIREBASE_CONFIG object or call EduFlowAuth.init(yourConfig).
3. Deploy the folder to any static hosting (GitHub Pages, Netlify, Firebase Hosting).
4. Ensure the pages load the Firebase CDN (already in signup/login). Adjust SDK versions if needed.

Notes:
- This template uses Firebase compat SDK to simplify integration into plain HTML pages.
- For production, replace compat SDK with modular SDK and secure rules for Realtime/Firestore/Storage.
