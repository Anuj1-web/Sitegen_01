
/*
  firebase.js
  Paste your Firebase web app config into `FIREBASE_CONFIG` below.
  This file exposes a global `window.EduFlowAuth` object with simple:
    - init(config)         -> initialize Firebase (call once)
    - signup(email, pass)  -> create user
    - login(email, pass)   -> sign in
    - logout()             -> sign out
    - onAuthStateChanged(cb) -> subscribe to auth changes

  NOTE: This file uses Firebase compat JS SDK for ease of integration with plain HTML pages.
  Replace the SDK versions in pages if desired.
*/

const EduFlowAuth = (function(){
  let app = null, auth = null;
  const FIREBASE_CONFIG = {
    // <-- paste your Firebase config here, example:
    // apiKey: "AIza....",
    // authDomain: "your-app.firebaseapp.com",
    // projectId: "your-app",
    // storageBucket: "your-app.appspot.com",
    // messagingSenderId: "1234567890",
    // appId: "1:123:web:abcdef"
  };

  function init(config){
    // merge provided config
    const cfg = Object.assign({}, FIREBASE_CONFIG, config || {});
    if(!cfg.apiKey) {
      console.warn('Firebase config appears empty. Please paste your web app config into firebase.js or call EduFlowAuth.init(config).');
    }
    // initialize compat app (pages load firebase-app-compat and firebase-auth-compat)
    try{
      app = firebase.initializeApp(cfg);
      auth = firebase.auth();
    }catch(e){
      console.warn('Firebase init error (maybe already initialized):', e);
      try{ auth = firebase.auth(); }catch(_){}
    }
    return {app, auth};
  }

  async function signup(email, password){
    if(!auth) init();
    const userCred = await auth.createUserWithEmailAndPassword(email, password);
    // Optionally send email verification:
    try{ await userCred.user.sendEmailVerification(); }catch(e){}
    return userCred;
  }

  async function login(email, password){
    if(!auth) init();
    return await auth.signInWithEmailAndPassword(email, password);
  }

  async function logout(){
    if(!auth) init();
    return await auth.signOut();
  }

  function onAuthStateChanged(cb){
    if(!auth) init();
    return auth.onAuthStateChanged(cb);
  }

  return { init, signup, login, logout, onAuthStateChanged };
})();

// expose globally for pages to use
window.EduFlowAuth = EduFlowAuth;
